
package exceptionPack;

public class Studentdet extends Abstract{
	String id,name;
	public void addStudent()
	{
		id="s1711134";
		name="RAHUL";
	}
	public void printStudent()
	{
		System.out.println("Student id is"+id);
		System.out.println("Student name is"+name);
	}
	public static void main(String[]args)
	{
		Studentdet stImpl=new Studentdet();
		stImpl.addStudent();
		stImpl.printStudent();
		Abstract st=new Studentdet();
		st.addStudent();
		st.printStudent();
	}
}