package exceptionPack;
class Manager 
{
	int mId;
	String mName;
	void addManager()
	{
		mId=200;
		mName="RA";
	}
	void displayManager()
	{
			System.out.println("Manager id is "+mId);
			System.out.println("Manager name "+mName);			
	}
}
class Clerk extends Manager
{
	int cId;
	String cName;
	void addClerk()
	{
		cId=200;
		cName="RA";
	}
	void displayClerk()
	{
			System.out.println("clerk id is "+cId);
			System.out.println("clerk name "+cName);	
	}
	@Override
	void addManager()
	{
		for(int i=65;i<=90;i++)
		{
			System.out.println((char)i);
		}
	}
}

public class ExmpleClass
{

	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub
		Clerk c=new Clerk();
		c.addManager();
		c.displayManager();
		
		c.addClerk();
		c.displayClerk();
		System.out.println(c.toString());
	}
}
